package com.cheezycode.notesample

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.cheezycode.notesample.databinding.ItemSearchResultBinding

data class SearchResult(val imageResId: Int, val title: String, val imdbRating: Float?)

class SearchResultAdapter(private val results: List<SearchResult>) : RecyclerView.Adapter<SearchResultAdapter.SearchResultViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SearchResultViewHolder {
        val binding = ItemSearchResultBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SearchResultViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SearchResultViewHolder, position: Int) {
        holder.bind(results[position])
    }

    override fun getItemCount() = results.size

    class SearchResultViewHolder(private val binding: ItemSearchResultBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(result: SearchResult) {
            binding.imageView.setImageResource(result.imageResId)
            binding.titleTextView.text = result.title
            if (result.imdbRating != null) {
                binding.imdbRatingTextView.text = "IMDb: ${result.imdbRating}"
                binding.imdbRatingTextView.visibility = View.VISIBLE
            } else {
                binding.imdbRatingTextView.visibility = View.GONE
            }
        }
    }
}
