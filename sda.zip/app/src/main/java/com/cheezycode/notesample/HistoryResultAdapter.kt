package com.cheezycode.notesample

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cheezycode.notesample.R

data class HistoryResult(val imageResId: Int, val title: String, val imdbRating: String?)

class HistoryResultAdapter(private val historyResults: List<HistoryResult>) :
    RecyclerView.Adapter<HistoryResultAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.image_view)
        val titleTextView: TextView = itemView.findViewById(R.id.title_text_view)
        val imdbRatingTextView: TextView = itemView.findViewById(R.id.imdb_rating_text_view)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_search_result, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val result = historyResults[position]
        holder.imageView.setImageResource(result.imageResId)
        holder.titleTextView.text = result.title
        if (result.imdbRating != null) {
            holder.imdbRatingTextView.visibility = View.VISIBLE
            holder.imdbRatingTextView.text = result.imdbRating
        } else {
            holder.imdbRatingTextView.visibility = View.GONE
        }
    }

    override fun getItemCount(): Int {
        return historyResults.size
    }
}
