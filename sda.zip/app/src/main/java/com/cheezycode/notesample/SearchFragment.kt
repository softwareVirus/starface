package com.cheezycode.notesample

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.cheezycode.notesample.databinding.FragmentSearchBinding

class SearchFragment : Fragment() {

    private var _binding: FragmentSearchBinding? = null
    private val binding get() = _binding!!
    private val searchResults = mutableListOf<SearchResult>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSearchBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupSearchBar()
        setupCategoryRadioGroup()
    }

    private fun setupRecyclerView() {
        binding.recyclerView.layoutManager = LinearLayoutManager(context)
        binding.recyclerView.adapter = SearchResultAdapter(searchResults)
    }

    private fun setupSearchBar() {
        binding.searchButton.setOnClickListener {
            val query = binding.searchBar.text.toString()
            val selectedCategory = view?.findViewById<RadioButton>(binding.categoryRadioGroup.checkedRadioButtonId)?.text.toString()
            performSearch(query, selectedCategory)
        }
    }

    private fun setupCategoryRadioGroup() {
        binding.categoryRadioGroup.check(R.id.radio_actor)
    }

    private fun performSearch(query: String, category: String) {
        // Perform search and update searchResults list
        // This is just a dummy implementation for demonstration purposes
        searchResults.clear()
        searchResults.add(SearchResult(R.drawable.rasim, "Rasim Öztekin", null))
        searchResults.add(SearchResult(R.drawable.ahmet, "Ahmet Mümtaz Taylan", null))
        searchResults.add(SearchResult(R.drawable.dogu, "Doğu Demirkol", null))
        searchResults.add(SearchResult(R.drawable.kural, "Ahmet Kural", null))
        searchResults.add(SearchResult(R.drawable.murat, "Murat Cemcir", null))
        searchResults.add(SearchResult(R.drawable.ozan, "Ozan Güven", null))
        searchResults.add(SearchResult(R.drawable.sahan, "Şahan Gökbakar", null))
        searchResults.add(SearchResult(R.drawable.sarp, "Sarp Apak", null))
        binding.recyclerView.adapter?.notifyDataSetChanged()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
