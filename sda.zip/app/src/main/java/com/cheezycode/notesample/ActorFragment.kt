package com.cheezycode.notesample

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment

class ActorFragment : Fragment() {

    private lateinit var actorPhotoImageView: ImageView
    private lateinit var actorNameTextView: TextView
    private lateinit var actorBioTextView: TextView
    private lateinit var actorUrlTextView: TextView
    private lateinit var moviesSeriesListLayout: LinearLayout

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_actor, container, false)

        actorPhotoImageView = view.findViewById(R.id.actor_photo)
        actorNameTextView = view.findViewById(R.id.actor_name)
        actorBioTextView = view.findViewById(R.id.actor_bio)
        actorUrlTextView = view.findViewById(R.id.actor_url)
        moviesSeriesListLayout = view.findViewById(R.id.movies_series_list)

        // Load actor details and set up views
        loadActorDetails()

        return view
    }

    private fun loadActorDetails() {
        // Replace with your actual logic to load actor details
        val actor = getActorDetails()

        actorNameTextView.text = actor.name
        actorBioTextView.text = actor.bio
        actorUrlTextView.text = actor.url

        // Load movies and series
        for (movie in actor.movies) {
            val movieView = layoutInflater.inflate(R.layout.item_movie_series, moviesSeriesListLayout, false)
            val moviePhotoImageView = movieView.findViewById<ImageView>(R.id.movie_photo)
            val movieNameTextView = movieView.findViewById<TextView>(R.id.movie_name)
            val movieRatingTextView = movieView.findViewById<TextView>(R.id.movie_rating)

            moviePhotoImageView.setImageResource(movie.photo) // Replace with actual image loading logic
            movieNameTextView.text = movie.name
            movieRatingTextView.text = "IMDb Rating: ${movie.rating}"

            moviesSeriesListLayout.addView(movieView)
        }
    }

    private fun getActorDetails(): Actor {
        // Replace with your actual logic to get the actor's details
        return Actor(
            "Şahan Gökbakar",
            "Şahan Gökbakar is a famous actor known for his roles in various movies and series.",
            "https://www.imdb.com/name/nm2201881/",
            listOf(
                Movie("Recep İvedik 1", R.drawable.rc1, 7.5),
                Movie("Recep İvedik 2", R.drawable.rc2, 8.2),
                Movie("Recep İvedik 3", R.drawable.rc3, 7.5),
                Movie("Recep İvedik 4", R.drawable.rc4, 8.2),
                Movie("Celal ile Ceren", R.drawable.cr, 7.5),
                // Add more movies and series here
            )
        )
    }

    data class Actor(val name: String, val bio: String, val url: String, val movies: List<Movie>)
    data class Movie(val name: String, val photo: Int, val rating: Double)
}
