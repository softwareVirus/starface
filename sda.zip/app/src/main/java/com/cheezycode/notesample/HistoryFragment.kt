package com.cheezycode.notesample

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.cheezycode.notesample.databinding.FragmentHistoryBinding

class HistoryFragment : Fragment() {

    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding!!
    private val historyResults = mutableListOf<HistoryResult>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        loadHistoryData()
    }

    private fun setupRecyclerView() {
        binding.recyclerView.layoutManager = LinearLayoutManager(context)
        binding.recyclerView.adapter = HistoryResultAdapter(historyResults)
    }

    private fun loadHistoryData() {
        // Load history data and update historyResults list
        // This is just a dummy implementation for demonstration purposes
        historyResults.clear()
        historyResults.add(HistoryResult(R.drawable.rasim, "Rasim Öztekin", null))
        historyResults.add(HistoryResult(R.drawable.ahmet, "Ahmet Mümtaz Taylan", null))
        historyResults.add(HistoryResult(R.drawable.dogu, "Doğu Demirkol", null))
        historyResults.add(HistoryResult(R.drawable.kural, "Ahmet Kural", null))
        historyResults.add(HistoryResult(R.drawable.murat, "Murat Cemcir", null))
        historyResults.add(HistoryResult(R.drawable.ozan, "Ozan Güven", null))
        historyResults.add(HistoryResult(R.drawable.sahan, "Şahan Gökbakar", null))
        historyResults.add(HistoryResult(R.drawable.sarp, "Sarp Apak", null))
        binding.recyclerView.adapter?.notifyDataSetChanged()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
