package com.cheezycode.notesample

import android.content.ClipData.Item
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.menu.MenuView.ItemView
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var appBarConfiguration: AppBarConfiguration

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.drawer_layout)
        val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController
        val navigationView: NavigationView = findViewById(R.id.navigation_view)
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        val menuButton: ImageButton = findViewById(R.id.menu_button)

        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(false) // Disable the default home as up button
        supportActionBar?.title = null // Remove title from toolbar

        appBarConfiguration = AppBarConfiguration(setOf(
            R.id.enterScreenFragment // Add all top-level destinations here
        ), drawerLayout)

        NavigationUI.setupWithNavController(navigationView, navController)

        menuButton.setOnClickListener {
            if (drawerLayout.isDrawerOpen(GravityCompat.END)) {
                drawerLayout.closeDrawer(GravityCompat.END)
            } else {
                drawerLayout.openDrawer(GravityCompat.END)
            }
        }

        navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_camera -> {
                    navController.navigate(R.id.cameraFragment)
                }
                R.id.nav_search -> {
                    navController.navigate(R.id.searchFragment)
                }
                R.id.nav_history -> {
                    navController.navigate(R.id.historyFragment)
                }
                R.id.nav_logout -> {
                    // Handle logout logic
                }
                R.id.nav_login -> {
                    navController.navigate(R.id.loginFragment)
                }
                R.id.nav_signup -> {
                    navController.navigate(R.id.registerFragment)
                }
                R.id.nav_user -> {
                    navController.navigate(R.id.profileFragment)
                }
            }
            drawerLayout.closeDrawer(GravityCompat.END)
            true
        }

        updateNavigationMenu(navigationView.menu, true, navController) // Update with actual login status
    }

    private fun updateNavigationMenu(menu: Menu, isLoggedIn: Boolean, navController: NavController) {
        menu.findItem(R.id.nav_login).isVisible = !isLoggedIn
        menu.findItem(R.id.nav_signup).isVisible = !isLoggedIn
        menu.findItem(R.id.nav_logout).isVisible = isLoggedIn
        menu.findItem(R.id.nav_camera).isVisible = true
        menu.findItem(R.id.nav_search).isVisible = isLoggedIn
        menu.findItem(R.id.nav_history).isVisible = true
        if (isLoggedIn) {
            val user = User("John", "Doe") // Replace with your method to get the user's details
            menu.findItem(R.id.nav_user).isVisible = true
            menu.findItem(R.id.nav_user).title = user.firstName + " " + user.lastName
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment)
        return NavigationUI.navigateUp(navController, appBarConfiguration) || super.onSupportNavigateUp()
    }

    private class User(val firstName: String, val lastName: String)
}
