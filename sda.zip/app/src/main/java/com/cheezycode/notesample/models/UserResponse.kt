package com.cheezycode.notesample.models

data class UserResponse(
    val token: String,
    val user: User
)