package com.cheezycode.notesample

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.constraintlayout.helper.widget.CircularFlow
import androidx.navigation.findNavController
import android.os.Bundle

class FaceOverlayView(context: Context, attrs: AttributeSet) : View(context, attrs) {
    private val paint = Paint().apply {
        style = Paint.Style.STROKE
        color = Color.WHITE // Change border color to black
        strokeWidth = 5f
        setShadowLayer(10f, 0f, 0f, Color.BLACK) // Add shadow to the circle
    }
    private val outlinePaint = Paint().apply {
        color = Color.BLACK
        textSize = 30f
        textAlign = Paint.Align.CENTER
        style = Paint.Style.STROKE
        strokeWidth = 1f // Adjust the width of the outline
    }
    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 30f
        textAlign = Paint.Align.CENTER
        style = Paint.Style.FILL_AND_STROKE
        setShadowLayer(5f, 0f, 0f, Color.BLACK) // Add shadow to the text
    }

    private var faces = listOf<RectF>()
    private var labels = listOf<String>()
    private var bitmapWidth: Int = 1
    private var bitmapHeight: Int = 1
    private var scaleX: Float = 1f
    private var scaleY: Float = 1f
    private var transX: Float = 0f
    private var transY: Float = 0f

    fun setFaces(faces: List<RectF>, labels: List<String>, bitmapWidth: Int, bitmapHeight: Int, scaleX: Float, scaleY: Float, transX: Float, transY: Float) {
        this.faces = faces
        this.labels = labels
        this.bitmapWidth = bitmapWidth
        this.bitmapHeight = bitmapHeight
        this.scaleX = scaleX
        this.scaleY = scaleY
        this.transX = transX
        this.transY = transY
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        faces.forEachIndexed { index, rect ->
            val centerX = (rect.left * scaleX + transX + rect.right * scaleX + transX) / 2
            val centerY = (rect.top * scaleY + transY + rect.bottom * scaleY + transY) / 2
            val radius = Math.min(rect.width() * scaleX, rect.height() * scaleY) / 2 * 1.5f

            // Draw circle
            canvas.drawCircle(centerX, centerY, radius, paint)

            // Draw text below the circle
            val textX = centerX
            val textY = centerY + radius + textPaint.textSize
            canvas.drawText(labels[index], textX, textY, textPaint)
            canvas.drawText(labels[index], textX, textY, outlinePaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            val x = event.x
            val y = event.y
            faces.forEachIndexed { index, rect ->
                val centerX = (rect.left * scaleX + transX + rect.right * scaleX + transX) / 2
                val centerY = (rect.top * scaleY + transY + rect.bottom * scaleY + transY) / 2
                val radius = Math.min(rect.width() * scaleX, rect.height() * scaleY) / 2 * 1.5f
                val scaledRect = RectF(
                    centerX - radius,
                    centerY - radius,
                    centerX + radius,
                    centerY + radius
                )
                if (scaledRect.contains(x, y)) {
                    val bundle = Bundle().apply {
                        putString("actor", labels[index])
                    }
                    findNavController().navigate(R.id.action_imagePreviewFragment_to_actorFragment, bundle)
                }
            }
        }
        return true
    }
}
